"""RookieRebels source modules."""
